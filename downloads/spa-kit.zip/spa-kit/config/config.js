const config = {
  website: {
    name: "liberstack/blog",
    description: "Desenvolvido por Guilherme Ribeiro.",
    author: "Guilherme Ribeiro",
    year: new Date().getFullYear(),
  },
  paths: {
    posts: "./data/posts.json",
    postsDir: "./posts/",
  },
  nav: [
    { label: "home", href: "#/" },
    { label: "sobre", href: "#/about" },
    { label: "contato", href: "#/contact" },
  ],
};

export default config;
