# frontlab/blog

> Blog estático com SPA em JavaScript puro. Sem frameworks, sem build step, sem enrolação. Escreve em Markdown, sobe no GitHub Pages, tá no ar.

---

## Stack

| | |
|---|---|
| **HTML + CSS + JS puro** | sem React, sem Vue, sem nada |
| **ES Modules** | import/export nativo no browser |
| **Hash routing** | navegação client-side via `#/rota` |
| **Markdown** | posts escritos em `.md`, renderizados com marked.js |
| **GitHub Pages** | deploy gratuito, automático, zero config |

---

## Estrutura

```
meu-blog/
│
├── index.html              ← entrada do SPA
├── 404.html                ← redireciona rotas para o SPA
├── style.css               ← estilos globais
│
├── config/
│   └── config.js           ← nome do site, nav, paths — edite aqui
│
├── src/
│   ├── app.js              ← inicializa tudo, registra rotas
│   ├── router.js           ← roteamento por hash
│   ├── ui.js               ← navbar, footer, injeção de conteúdo
│   └── pages/
│       ├── home.js         ← lista de posts + busca em tempo real
│       ├── about.js        ← página sobre
│       ├── contact.js      ← página de contato
│       ├── legal.js        ← privacidade e termos
│       └── 404.js          ← página de erro
│
├── data/
│   └── posts.json          ← índice de todos os posts
│
├── posts/
│   └── meu-post.md         ← conteúdo dos posts em Markdown
│
└── assets/
    └── icon.png            ← logo/ícone do site
```

---

## Como funciona

```
index.html
  └─ carrega src/app.js
       ├─ config/config.js   → nome, nav, paths
       ├─ src/router.js      → mapeia #/rota para a página certa
       ├─ src/ui.js          → renderiza navbar e footer
       └─ src/pages/         → cada rota é um módulo JS
            └─ home.js busca posts.json → lista os posts
                 └─ clique no post → busca o .md → renderiza com marked.js
```

Roteamento via hash — nenhuma requisição ao servidor ao navegar:

```
/seuusuario.github.io/blog/#/           → home
/seuusuario.github.io/blog/#/about      → sobre
/seuusuario.github.io/blog/#/p/slug     → post
```

O `404.html` existe porque o GitHub Pages serve um 404 quando alguém acessa uma URL diretamente. Ele detecta o caminho e redireciona para o hash correto, fazendo o SPA funcionar normalmente.

---

## Começando

### 1. Cria o repositório no GitHub

- Acesse [github.com](https://github.com) → **New**
- Nome: `blog` (vai aparecer na URL: `seuusuario.github.io/blog`)
- Marque **Public** e **Add a README file**
- **Create repository**

### 2. Sobe os arquivos

**Pelo site** (mais fácil):

1. Abra o repositório → **Add file → Upload files**
2. Arraste todos os arquivos e pastas
3. **Commit changes**

**Via terminal:**

```bash
git clone https://github.com/seuusuario/blog.git
cd blog
# cole os arquivos do projeto aqui
git add .
git commit -m "feat: primeiro deploy"
git push
```

### 3. Ativa o GitHub Pages

1. Repositório → **Settings → Pages**
2. Branch: `main` / pasta: `/ (root)`
3. **Save**

Após 1-2 minutos o site estará em:

```
https://seuusuario.github.io/blog
```

---

## Configurando o site

Tudo que você precisa mudar fica em `config/config.js`:

```js
const config = {
  website: {
    name: 'meu-blog',
    description: 'Descrição do seu site.',
    author: 'Seu Nome',
    year: new Date().getFullYear(),
  },
  paths: {
    posts: './data/posts.json',
    postsDir: './posts/',
  },
  nav: [
    { label: 'home', href: '#/' },
    { label: 'sobre', href: '#/about' },
    { label: 'contato', href: '#/contact' },
  ],
};
```

---

## Publicando um post

**1. Cria o arquivo Markdown em `posts/`:**

```markdown
# Título do Post

Conteúdo em **Markdown** normal.

## Subtítulo

- item 1
- item 2

```js
const exemplo = "código com syntax highlight";
```
```

**2. Adiciona a entrada em `data/posts.json`:**

```json
[
  {
    "slug": "meu-primeiro-post",
    "title": "Meu Primeiro Post",
    "date": "2025-01-15",
    "tag": ["html", "css"],
    "excerpt": "Resumo que aparece na listagem.",
    "file": "meu-primeiro-post.md"
  }
]
```

**3. Sobe para o GitHub:**

```bash
git add .
git commit -m "post: meu primeiro post"
git push
```

Pronto. O site atualiza em segundos.

---

## Adicionando uma nova página

**1. Cria `src/pages/projetos.js`:**

```js
import ui from '../ui.js';

function projetos() {
  ui.setContent(`
    <div class="page-header">
      <h1>Projetos</h1>
    </div>
    <p>Seus projetos aqui.</p>
  `);
}

export default projetos;
```

**2. Registra em `src/app.js`:**

```js
import projetos from './pages/projetos.js';
// ...
router.register('/projetos', projetos);
```

**3. Adiciona na nav em `config/config.js`:**

```js
{ label: 'projetos', href: '#/projetos' },
```

---

## Problemas comuns

**Site em branco** → abre o console (F12) e vê o erro. Quase sempre é caminho errado no `config.js` ou arquivo faltando.

**Posts não carregam** → valida o `data/posts.json` em [jsonlint.com](https://jsonlint.com).

**CSS não aplica** → GitHub Pages é case-sensitive. `Style.css` ≠ `style.css`.

**Imagens não aparecem** → usa caminhos relativos sem `/` no início: `assets/icon.png`, não `/assets/icon.png`.

**404 não redireciona** → confirma que o nome do repositório em `404.html` está correto.

---

## Licença

Livre para usar e modificar. Atribuição é bem-vinda.