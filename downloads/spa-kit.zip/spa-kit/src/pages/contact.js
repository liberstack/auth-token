import ui from '../ui.js';

function contact() {
  ui.setContent(`
    <div class="page-header">
      <h1>Contato</h1>
    </div>
    <ul class="contact-links">
      <li><a href="mailto:topverbs@gmail.com" target="_blank">topverbs@gmail.com</a></li>
      <li><a href="https://linkedin.com/in/gribeirodev" target="_blank">linkedin.com/in/gribeirodev</a></li>
      <li><a href="https://github.com/liberstack" target="_blank">github.com/liberstack</a></li>
    </ul>
  `);
}

export default contact;